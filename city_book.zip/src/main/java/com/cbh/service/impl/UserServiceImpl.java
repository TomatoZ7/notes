package com.cbh.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cbh.dao.UserDao;
import com.cbh.domain.User;
import com.cbh.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
    UserDao userDao;
	
	@Override
	public User getUserById(int id) {
		return userDao.getUserById(id);
	}
	
	@Override
	public int delUserById(int id) {
		return userDao.delUserById(id);
	}
	
	@Override
	public int updateUser(Map param) {
		return userDao.updateUser(param);
	}
	
	@Override
	public int insertUser(User user) {
		return userDao.insertUser(user);
	}
}
