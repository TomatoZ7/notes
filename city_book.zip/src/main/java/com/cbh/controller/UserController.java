package com.cbh.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cbh.domain.User;
import com.cbh.pojo.Result;
import com.cbh.service.UserService;

@RequestMapping(value = "/user")
@RestController
public class UserController {
	@Autowired
    UserService userService;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public User getUserById(@PathVariable int id) {
        User user = userService.getUserById(id);
        if (user == null) {
        	// TODO �׳��쳣
        }
        return user;
    }
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public Result delStuById(@PathVariable int id) {
        int res = userService.delUserById(id);
        if (res == 0) {
        	return new Result(403, "ɾ��ʧ��");
        }
            
        return new Result(200, "ɾ�������ɹ�");
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public Result addAStu(User user) {
        int result = userService.insertUser(user);
        if (result == 0) {
        	return new Result(403, "����ʧ�ܡ�");
        }

        return new Result(200, "���ӳɹ���");
    }
    
    @RequestMapping(value="/update",method = RequestMethod.PUT)
    public Result updateStu(User user){
        System.out.println(user);
        Map<String,String> param = new HashMap<>();
        param.put("id", Integer.toString(user.getId()));
        param.put("account", user.getAccount());
        param.put("password", user.getPassword());
        param.put("name", user.getName());
        param.put("gender", Integer.toString(user.getGender()));
        param.put("phone", user.getPhone());
        param.put("avatar", user.getAvatar());
        param.put("status", Integer.toString(user.getStatus()));
        param.put("has_rights", Integer.toString(user.getHas_rights()));
        param.put("create_time", user.getCreate_time());
        
        int result = userService.updateUser(param);
        if (result == 0) {
        	return new Result(403, "����ʧ�ܡ�");
        }
            
        return new Result(200, "���³ɹ���");
    }
}
