package city_book;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cbh.dao.UserDao;
import com.cbh.domain.User;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class UserTest {
	@Autowired
	UserDao userDao;
	
	@Test
    public void testQueryUser(){
        User user = userDao.getUserById(1);
        System.out.println(user);
    }
	
	@Test
	public void testDelUser() {
		int result = userDao.delUserById(2);
        System.out.println(result);
	}
	
	@Test
	public void testUpdateUser() {
		Map<String,String> param = new HashMap<>();
        param.put("id","1");
        param.put("name", "admin");
        int result = userDao.updateUser(param);
        System.out.println(result);
	}
	
	@Test
	public void testInsertUser() {
		User user = new User();
		user.setName("manager");
		user.setPassword("asd123asd");
        user.setAccount("manager888");
		user.setGender(0);
		user.setPhone("18819917710");
		user.setAvatar("test9572");
		user.setStatus(1);
		user.setHas_rights(1);
		user.setCreate_time("2021-01-05 12:10:59");
        int result = userDao.insertUser(user);
        System.out.println(result);
	}
}
